# Tool spam tin nhắn
## [Bấm vào đây để tải xuống](https://github.com/DauDau432/Spam-message/archive/refs/heads/main.zip)
### Yêu cầu
`python 3` ([tải xuống tại đây](https://www.python.org/))

***Để gửi tin nhắn ngẫu nhiên hàng loạt các bạn thêm dấu `,` giữa 2 đoạn tin nhắn***
------------------------------------------------------------------

ví dụ:
```
Đậu kute , Đậu kute x1 , Đậu kute x2 
```
